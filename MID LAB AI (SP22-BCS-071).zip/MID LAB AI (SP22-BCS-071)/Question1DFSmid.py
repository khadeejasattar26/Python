def dfs(graph, start, goal, current_path=[], all_paths=[]):


    current_path = current_path + [start]

    if start == goal:
        all_paths.append(current_path)
    
    for neighbor in graph[start]:
        if neighbor not in current_path:
            all_paths = dfs(graph, neighbor, goal, current_path, all_paths)
    
    return all_paths

graph = {
    'A': ['B', 'C', 'D'],
    'B': ['A', 'E'],
    'C': ['A', 'E', 'F'],
    'D': ['A', 'G'],
    'E': ['B', 'C'],
    'F': ['C', 'G', 'H', 'I'],
    'G': ['D', 'F', 'J'],
    'H': ['F'],
    'I': ['F'],
    'J': ['G']
}

start_node = 'A'
end_node = 'J'

all_paths_found = dfs(graph, start_node, end_node)

if all_paths_found:
    print("All paths from", start_node, "to", end_node, ":")
    for path in all_paths_found:
        print(path)
else:
    print("No path found from", start_node, "to", end_node)
